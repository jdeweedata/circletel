import React from 'react';

export interface ResourceItem {
  id: string;
  title: string;
  type: 'Free' | 'Guide' | 'Tools' | 'Template';
  duration: string;
  description: string;
  features: string[];
  ctaText: string;
  icon: React.ComponentType<any>;
}

export interface DownloadItem {
  id: string;
  title: string;
  format: string;
  description: string;
  ctaText: string;
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
  timestamp: Date;
}

export interface NavItem {
  label: string;
  href: string;
  hasDropdown?: boolean;
}