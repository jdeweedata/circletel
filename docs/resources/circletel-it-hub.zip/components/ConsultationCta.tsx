import React from 'react';
import { Users } from 'lucide-react';

const ConsultationCta: React.FC = () => {
  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-[#eae8e4] to-[#d6d3cd] rounded-3xl p-8 md:p-12 text-center shadow-xl relative overflow-hidden">
           {/* Abstract shapes */}
           <div className="absolute -top-24 -left-24 w-48 h-48 bg-white/20 rounded-full blur-2xl"></div>
           <div className="absolute -bottom-24 -right-24 w-48 h-48 bg-orange-200/20 rounded-full blur-2xl"></div>

           <div className="relative z-10 flex flex-col items-center">
             <div className="bg-white p-4 rounded-full shadow-sm mb-6 text-brand-orange">
                <Users size={32} />
             </div>

             <h2 className="text-3xl font-bold text-slate-800 mb-4">Need Expert Guidance?</h2>
             <p className="text-slate-600 mb-8 max-w-xl leading-relaxed">
               While our resources are comprehensive, sometimes you need personalized advice. 
               Our IT experts are available to discuss your specific situation and provide tailored recommendations.
             </p>

             <div className="flex flex-col sm:flex-row gap-4 w-full justify-center">
               <button className="px-8 py-3 bg-brand-orange text-white rounded-lg font-semibold shadow-md hover:bg-brand-darkOrange hover:shadow-lg transition-all transform hover:-translate-y-0.5">
                 Book Free Consultation
               </button>
               <button className="px-8 py-3 bg-transparent border-2 border-slate-400 text-slate-700 rounded-lg font-semibold hover:bg-white hover:border-white transition-all">
                 View IT Services
               </button>
             </div>
           </div>
        </div>
      </div>
    </section>
  );
};

export default ConsultationCta;