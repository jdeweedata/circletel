import React, { useState } from 'react';
import { Menu, X, ChevronDown, Phone, User } from 'lucide-react';
import { NavItem } from '../types';

const navItems: NavItem[] = [
  { label: 'Home', href: '#' },
  { label: 'Managed IT', href: '#', hasDropdown: true },
  { label: 'Connectivity', href: '#', hasDropdown: true },
  { label: 'Cloud & Hosting', href: '#', hasDropdown: true },
  { label: 'Resources', href: '#', hasDropdown: true },
];

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 w-full bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo Area */}
          <div className="flex-shrink-0 flex items-center cursor-pointer">
             <div className="w-10 h-10 rounded-full bg-gradient-to-br from-brand-orange to-brand-darkOrange flex items-center justify-center text-white font-bold text-xl mr-2">
               C
             </div>
             <span className="font-bold text-2xl text-slate-800 tracking-tight">Circle<span className="text-brand-orange">Tel</span></span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8 items-center">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="text-slate-600 hover:text-brand-orange font-medium transition-colors duration-200 flex items-center gap-1 text-sm lg:text-base"
              >
                {item.label}
                {item.hasDropdown && <ChevronDown size={14} />}
              </a>
            ))}
          </nav>

          {/* Desktop CTAs */}
          <div className="hidden md:flex items-center space-x-4">
            <button className="text-brand-orange font-semibold hover:text-brand-darkOrange transition-colors text-sm">
              Request Quote
            </button>
            <button className="bg-brand-orange hover:bg-brand-darkOrange text-white px-5 py-2.5 rounded-lg font-medium transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5 flex items-center gap-2 text-sm">
              <User size={16} />
              Customer Login
            </button>
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-600 hover:text-slate-900 focus:outline-none"
            >
              {isMobileMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-slate-100 absolute w-full shadow-xl">
          <div className="px-4 pt-2 pb-6 space-y-2">
            {navItems.map((item) => (
              <a
                key={item.label}
                href={item.href}
                className="block px-3 py-3 text-base font-medium text-slate-600 hover:text-brand-orange hover:bg-orange-50 rounded-md"
              >
                {item.label}
              </a>
            ))}
            <div className="mt-6 border-t border-slate-100 pt-4 flex flex-col space-y-3">
              <button className="w-full text-center text-brand-orange font-semibold py-2 border border-brand-orange rounded-lg">
                Request Quote
              </button>
              <button className="w-full text-center bg-brand-orange text-white font-medium py-3 rounded-lg shadow-sm">
                Customer Login
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;