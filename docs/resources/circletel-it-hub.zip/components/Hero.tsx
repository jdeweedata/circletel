import React from 'react';
import { ArrowRight, CheckCircle2, TrendingUp, Clock, Zap } from 'lucide-react';

const stats = [
  { label: 'Businesses Assisted', value: '2,500+', icon: CheckCircle2 },
  { label: 'Client Savings Found', value: 'R2.5M+', icon: TrendingUp },
  { label: 'Time to Insight', value: '~15 min', icon: Clock },
  { label: 'Platform Cost', value: 'Free', icon: Zap },
];

const Hero: React.FC = () => {
  return (
    <section className="relative overflow-hidden bg-slate-50 pt-16 pb-12 lg:pt-24 lg:pb-20">
      {/* Background Decor */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-7xl pointer-events-none">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-100/50 rounded-full blur-3xl opacity-60"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-100/50 rounded-full blur-3xl opacity-60"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-orange-50 border border-orange-100 text-brand-darkOrange text-sm font-medium mb-6 animate-fade-in-up">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-orange opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-brand-orange"></span>
          </span>
          New: AI-Powered Infrastructure Audits
        </div>

        <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 tracking-tight mb-6">
          Expert IT Strategy. <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-brand-orange to-red-500">Zero Consulting Fees.</span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-slate-600 mb-10 leading-relaxed">
          Stop guessing with your technology. Access professional-grade assessments, budgeting tools, and 24/7 AI guidance to <span className="font-semibold text-slate-900">audit risks</span>, <span className="font-semibold text-slate-900">cut costs</span>, and <span className="font-semibold text-slate-900">secure your business</span>—completely free.
        </p>

        <div className="flex flex-col sm:flex-row justify-center items-center gap-4 mb-16">
          <button className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-brand-orange to-brand-darkOrange text-white rounded-xl font-semibold shadow-lg shadow-orange-500/20 hover:shadow-orange-500/40 transition-all transform hover:-translate-y-1 flex items-center justify-center gap-2">
            Start Free Assessment
            <ArrowRight size={18} />
          </button>
          <button className="w-full sm:w-auto px-8 py-4 bg-white text-slate-700 border border-slate-200 rounded-xl font-semibold hover:bg-slate-50 hover:border-slate-300 transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md">
            Explore Resources
          </button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-12 border-t border-slate-200 pt-12">
          {stats.map((stat, idx) => (
            <div key={idx} className="flex flex-col items-center group">
              <div className="mb-3 p-3 bg-white rounded-full shadow-sm text-brand-orange group-hover:scale-110 group-hover:shadow-md transition-all duration-300 border border-slate-100">
                 <stat.icon size={24} />
              </div>
              <span className="text-2xl lg:text-3xl font-bold text-slate-900 mb-1">{stat.value}</span>
              <span className="text-sm text-slate-500 font-medium uppercase tracking-wide">{stat.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Hero;