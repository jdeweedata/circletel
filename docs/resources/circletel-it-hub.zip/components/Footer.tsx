import React from 'react';
import { Phone, Mail, MapPin, Facebook, Linkedin, X } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-brand-navy text-slate-300 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center border-b border-slate-700 pb-8 mb-12 gap-6">
          <div className="flex items-center gap-6 text-sm font-medium">
             <a href="tel:0870876305" className="flex items-center gap-2 hover:text-brand-orange transition-colors">
               <Phone size={16} className="text-brand-orange" /> 087 087 6305
             </a>
             <a href="mailto:contactus@circletel.co.za" className="flex items-center gap-2 hover:text-brand-orange transition-colors">
               <Mail size={16} className="text-brand-orange" /> contactus@circletel.co.za
             </a>
          </div>
          <button className="bg-brand-orange text-white px-6 py-2 rounded-full text-sm font-semibold hover:bg-brand-darkOrange transition-colors">
            Contact Us
          </button>
        </div>

        {/* Grid Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand Column */}
          <div>
            <div className="flex items-center mb-6">
             <div className="w-8 h-8 rounded-full bg-gradient-to-br from-brand-orange to-brand-darkOrange flex items-center justify-center text-white font-bold text-lg mr-2">
               C
             </div>
             <span className="font-bold text-xl text-white">Circle<span className="text-brand-orange">Tel</span></span>
            </div>
            <p className="text-sm leading-relaxed text-slate-400 mb-6">
              Making IT simple and affordable for businesses of all sizes. We provide expert IT services with a recipe for success.
            </p>
            <div className="flex gap-3">
              {[Facebook, Linkedin, X].map((Icon, idx) => (
                <a key={idx} href="#" className="w-9 h-9 rounded-full bg-slate-700 flex items-center justify-center hover:bg-brand-orange text-white transition-colors">
                  <Icon size={16} />
                </a>
              ))}
            </div>
          </div>

          {/* Links Columns */}
          {[
            {
              title: 'Managed IT',
              links: ['Complete IT Management', 'Small Business IT', 'Mid-Size Business IT', 'Growth-Ready IT', 'Security Solutions', 'Pricing']
            },
            {
              title: 'Connectivity & Cloud',
              links: ['Wi-Fi as a Service', 'Fixed Wireless', 'Fibre', 'Service Bundles', 'Cloud Migration', 'Hosting Solutions', 'Backup & Recovery']
            },
            {
              title: 'Resources & Support',
              links: ['Resources Hub', 'IT Assessment', 'Power Backup', 'Connectivity Guide', 'Wi-Fi Toolkit', 'Privacy Policy', 'Terms & Conditions']
            }
          ].map((col, idx) => (
            <div key={idx}>
              <h4 className="text-white font-bold mb-6">{col.title}</h4>
              <ul className="space-y-3">
                {col.links.map((link, lIdx) => (
                  <li key={lIdx}>
                    <a href="#" className="text-sm hover:text-brand-orange transition-colors flex items-center gap-2 group">
                      <span className="w-0 group-hover:w-2 transition-all h-px bg-brand-orange"></span>
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-slate-700 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-slate-500">
          <p>&copy; 2025 CircleTel. All rights reserved.</p>
          <div className="flex items-center gap-2">
            <MapPin size={14} />
            <span>West House, 7 Autumn Road, Rivonia, Johannesburg, 2128</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;