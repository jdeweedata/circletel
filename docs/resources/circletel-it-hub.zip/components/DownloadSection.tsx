import React from 'react';
import { Download, FileSpreadsheet, FileText, ShieldCheck } from 'lucide-react';
import { DownloadItem } from '../types';

const downloads: DownloadItem[] = [
  {
    id: 'd1',
    title: 'IT Budget Template',
    format: 'Excel Spreadsheet',
    description: 'Professional spreadsheet template for planning your annual IT budget with auto-calculations.',
    ctaText: 'Download Template',
  },
  {
    id: 'd2',
    title: 'Security Checklist',
    format: 'PDF Document',
    description: 'Essential 25-point security checklist for small businesses to ensure basic compliance.',
    ctaText: 'Download Checklist',
  },
  {
    id: 'd3',
    title: 'Network Doc Template',
    format: 'Word Document',
    description: 'Standardized template for documenting your network infrastructure and assets.',
    ctaText: 'Download Doc',
  },
];

const DownloadSection: React.FC = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-3">Quick Downloads</h2>
          <p className="text-slate-600">Useful templates and checklists you can download and use immediately.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {downloads.map((item) => (
            <div key={item.id} className="group p-6 bg-white border border-slate-200 rounded-xl hover:border-brand-orange/50 transition-all hover:shadow-lg flex flex-col items-center text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-orange-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
              
              <div className="w-12 h-12 bg-slate-100 rounded-lg flex items-center justify-center text-slate-600 mb-4 group-hover:bg-brand-orange group-hover:text-white transition-colors duration-300">
                {item.title.includes('Budget') ? <FileSpreadsheet size={24} /> : item.title.includes('Security') ? <ShieldCheck size={24} /> : <FileText size={24} />}
              </div>
              
              <h3 className="text-lg font-bold text-slate-900 mb-1">{item.title}</h3>
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wide mb-3">{item.format}</span>
              
              <p className="text-sm text-slate-600 mb-6 line-clamp-2">
                {item.description}
              </p>

              <button className="mt-auto text-sm font-medium text-brand-orange flex items-center gap-2 px-4 py-2 rounded-lg hover:bg-orange-50 transition-colors border border-transparent hover:border-orange-100">
                {item.ctaText}
                <Download size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default DownloadSection;