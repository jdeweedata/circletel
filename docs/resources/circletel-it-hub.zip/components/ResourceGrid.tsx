import React from 'react';
import { Activity, BatteryCharging, Globe, Wifi, ArrowRight, Check } from 'lucide-react';
import { ResourceItem } from '../types';

const resources: ResourceItem[] = [
  {
    id: 'r1',
    title: 'IT Health Assessment',
    type: 'Free',
    duration: '15 minutes to complete',
    description: 'Get a comprehensive evaluation of your current IT infrastructure with actionable recommendations and a customized roadmap.',
    features: ['Network Security Audit', 'Performance Analysis', 'Risk Assessment', 'Improvement Roadmap'],
    ctaText: 'Start Free Assessment',
    icon: Activity,
  },
  {
    id: 'r2',
    title: 'Power Backup Solutions',
    type: 'Guide',
    duration: '10 minutes to complete',
    description: 'Protect your business from power outages with our comprehensive UPS and backup power guide based on your equipment load.',
    features: ['UPS Sizing Calculator', 'Backup Time Estimates', 'Cost Analysis', 'Installation Guide'],
    ctaText: 'View Power Guide',
    icon: BatteryCharging,
  },
  {
    id: 'r3',
    title: 'Business Connectivity Guide',
    type: 'Guide',
    duration: '12 minutes to complete',
    description: 'Complete guide to choosing the right internet connectivity for your business needs, balancing speed, reliability, and cost.',
    features: ['Speed Requirements', 'Technology Comparison', 'Cost Calculator', 'Provider Evaluation'],
    ctaText: 'View Connectivity Guide',
    icon: Globe,
  },
  {
    id: 'r4',
    title: 'Wi-Fi Planning Toolkit',
    type: 'Tools',
    duration: '5 minutes to complete',
    description: 'Professional tools and calculators for planning your business Wi-Fi deployment ensuring maximum coverage and security.',
    features: ['Coverage Calculator', 'Access Point Planner', 'Speed Requirements', 'Security Checklist'],
    ctaText: 'Open Wi-Fi Toolkit',
    icon: Wifi,
  },
];

const ResourceCard: React.FC<{ item: ResourceItem }> = ({ item }) => {
  const Icon = item.icon;
  
  // Badge Color Logic
  const getBadgeColor = (type: string) => {
    switch(type) {
      case 'Free': return 'bg-green-500';
      case 'Guide': return 'bg-blue-500';
      case 'Tools': return 'bg-brand-orange';
      default: return 'bg-slate-500';
    }
  };

  return (
    <div className="relative bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group flex flex-col h-full overflow-hidden">
      {/* Top Decor Bar */}
      <div className={`h-1.5 w-full ${item.title.includes('Health') ? 'bg-green-500' : item.title.includes('Power') ? 'bg-blue-500' : item.title.includes('Connectivity') ? 'bg-purple-500' : 'bg-brand-orange'}`}></div>
      
      <div className="p-8 flex flex-col flex-1">
        <div className="flex justify-between items-start mb-6">
          <div className={`p-3 rounded-xl ${item.title.includes('Health') ? 'bg-green-50 text-green-600' : item.title.includes('Power') ? 'bg-blue-50 text-blue-600' : item.title.includes('Connectivity') ? 'bg-purple-50 text-purple-600' : 'bg-orange-50 text-brand-orange'}`}>
            <Icon size={32} />
          </div>
          <span className={`${getBadgeColor(item.type)} text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm`}>
            {item.type}
          </span>
        </div>

        <h3 className="text-2xl font-bold text-slate-800 mb-2">{item.title}</h3>
        
        <div className="flex items-center gap-2 text-slate-400 text-sm mb-4">
          <div className="w-4 h-4 rounded-full border border-slate-300 flex items-center justify-center">
            <div className="w-2 h-0.5 bg-slate-300"></div>
          </div>
          {item.duration}
        </div>

        <p className="text-slate-600 mb-6 leading-relaxed text-sm flex-grow">
          {item.description}
        </p>

        <div className="bg-slate-50 rounded-xl p-5 mb-8">
          <h4 className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-3">What's Included:</h4>
          <ul className="space-y-2">
            {item.features.map((feature, idx) => (
              <li key={idx} className="flex items-center gap-2 text-sm text-slate-700">
                <Check size={16} className="text-green-500 flex-shrink-0" />
                {feature}
              </li>
            ))}
          </ul>
        </div>

        <button className={`w-full py-3 px-4 rounded-lg font-medium flex items-center justify-center gap-2 transition-all
          ${item.type === 'Free' || item.title.includes('Connectivity') 
            ? 'bg-brand-orange text-white hover:bg-brand-darkOrange shadow-md hover:shadow-lg' 
            : 'bg-white border border-slate-300 text-slate-700 hover:bg-slate-50 hover:border-slate-400'
          }`}>
          {item.ctaText}
          <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
};

const ResourceGrid: React.FC = () => {
  return (
    <section className="py-20 bg-slate-50" id="resources">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Featured Resources</h2>
          <p className="text-lg text-slate-600">
            Comprehensive tools and guides created by our IT experts to help you make better technology decisions, backed by real-world data.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {resources.map((item) => (
            <ResourceCard key={item.id} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default ResourceGrid;