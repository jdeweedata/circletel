import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import ResourceGrid from './components/ResourceGrid';
import DownloadSection from './components/DownloadSection';
import ConsultationCta from './components/ConsultationCta';
import Footer from './components/Footer';
import AiAssistant from './components/AiAssistant';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col bg-slate-50 font-sans selection:bg-brand-orange selection:text-white">
      <Header />
      
      <main className="flex-grow">
        <Hero />
        <ResourceGrid />
        <DownloadSection />
        <ConsultationCta />
      </main>

      <Footer />
      
      {/* Floating AI Assistant Component */}
      <AiAssistant />
    </div>
  );
};

export default App;