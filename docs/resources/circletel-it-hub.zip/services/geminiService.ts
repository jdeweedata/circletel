import { GoogleGenAI } from "@google/genai";

// Initialize the client with the API key from the environment
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateITAdvice = async (userQuery: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userQuery,
      config: {
        systemInstruction: `You are "CircleBot", an expert Senior IT Consultant for CircleTel. 
        Your goal is to help business owners and IT managers make informed decisions about their infrastructure.
        
        Keep your answers professional, concise (under 150 words), and actionable.
        
        If the user asks about:
        - IT Health: Recommend the "IT Health Assessment".
        - Power/Electricity: Recommend the "Power Backup Solutions" guide.
        - Internet/Connectivity: Recommend the "Business Connectivity Guide".
        - WiFi: Recommend the "Wi-Fi Planning Toolkit".
        - Budgets: Recommend the "IT Budget Template".
        
        Always be polite and helpful.`,
      },
    });

    return response.text || "I apologize, I couldn't generate a response at this moment.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "I'm currently experiencing high traffic. Please try asking again in a moment.";
  }
};