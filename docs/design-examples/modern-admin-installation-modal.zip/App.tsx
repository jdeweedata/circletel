import React, { useState } from 'react';
import CompleteInstallationModal from './components/CompleteInstallationModal';

const App = () => {
  const [isModalOpen, setIsModalOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-100 font-sans text-gray-900">
      
      {/* Mock Navigation Bar */}
      <nav className="bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-orange-600 rounded-lg flex items-center justify-center text-white font-bold">CT</div>
            <span className="font-semibold text-gray-700">Admin Panel</span>
          </div>
          <div className="hidden md:flex gap-6 text-sm font-medium text-gray-500">
            <span className="text-gray-900">Dashboard</span>
            <span>Products</span>
            <span>Quotes</span>
            <span className="text-primary-700">Orders</span>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-full bg-gray-200"></div>
        </div>
      </nav>

      <div className="flex">
        {/* Mock Sidebar */}
        <aside className="w-64 hidden lg:block h-[calc(100vh-60px)] sticky top-[60px] bg-white border-r border-gray-200 p-6 space-y-6">
          <div className="space-y-1">
             <div className="px-3 py-2 bg-gray-100 rounded-md text-sm font-medium text-gray-900">All Orders</div>
             <div className="px-3 py-2 text-sm font-medium text-gray-600">Installation Schedule</div>
             <div className="px-3 py-2 text-sm font-medium text-gray-600">Technicians</div>
          </div>
        </aside>

        {/* Mock Main Content */}
        <main className="flex-1 p-8">
           <div className="max-w-5xl mx-auto">
             <div className="flex justify-between items-center mb-8">
               <div>
                  <h1 className="text-2xl font-bold text-gray-900">Order Details</h1>
                  <p className="text-gray-500 mt-1">View and manage order #ORD-20251108-9841</p>
               </div>
               <div className="flex gap-3">
                 <button className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm font-medium">Print</button>
                 <button className="px-4 py-2 border border-gray-300 rounded-lg bg-white text-sm font-medium">Export</button>
               </div>
             </div>

             {/* Order Status Visualization */}
             <div className="bg-white rounded-xl border border-gray-200 p-8 mb-8">
                <div className="flex items-center justify-between relative">
                  <div className="absolute top-1/2 left-0 w-full h-1 bg-gray-100 -z-10"></div>
                  
                  <div className="flex flex-col items-center gap-2 bg-white px-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 text-green-600 flex items-center justify-center border-2 border-green-500">✓</div>
                    <span className="text-xs font-bold text-gray-900 uppercase">Order Received</span>
                  </div>
                  <div className="flex flex-col items-center gap-2 bg-white px-4">
                    <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center border-2 border-blue-500 animate-pulse">2</div>
                    <span className="text-xs font-bold text-blue-600 uppercase">Installation</span>
                  </div>
                  <div className="flex flex-col items-center gap-2 bg-white px-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 text-gray-300 flex items-center justify-center border-2 border-gray-200">3</div>
                    <span className="text-xs font-bold text-gray-400 uppercase">Completion</span>
                  </div>
                  <div className="flex flex-col items-center gap-2 bg-white px-4">
                    <div className="w-10 h-10 rounded-full bg-gray-100 text-gray-300 flex items-center justify-center border-2 border-gray-200">4</div>
                    <span className="text-xs font-bold text-gray-400 uppercase">Active</span>
                  </div>
                </div>
             </div>

             <div className="grid grid-cols-2 gap-8">
                <div className="bg-white rounded-xl border border-gray-200 p-6 h-64">
                   <h3 className="font-semibold text-gray-900 mb-4">Customer Info</h3>
                   <div className="space-y-4">
                      <div>
                        <span className="block text-xs text-gray-500 uppercase">Full Name</span>
                        <span className="text-gray-900">Shaun Robertson</span>
                      </div>
                      <div>
                        <span className="block text-xs text-gray-500 uppercase">Phone</span>
                        <span className="text-blue-600">0826574256</span>
                      </div>
                   </div>
                </div>
                <div className="bg-white rounded-xl border border-gray-200 p-6 h-64">
                   <h3 className="font-semibold text-gray-900 mb-4">Payment Info</h3>
                   <div>
                        <span className="block text-xs text-gray-500 uppercase">Status</span>
                        <span className="inline-block mt-1 px-2 py-1 bg-yellow-100 text-yellow-700 text-xs font-medium rounded">Pending</span>
                      </div>
                </div>
             </div>
             
             <button 
               onClick={() => setIsModalOpen(true)}
               className="mt-8 px-6 py-3 bg-primary-700 text-white rounded-lg hover:bg-primary-800 transition-colors"
             >
               Re-open Modal
             </button>
           </div>
        </main>
      </div>

      <CompleteInstallationModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)}
        orderId="ORD-20251108-9841"
      />
    </div>
  );
};

export default App;