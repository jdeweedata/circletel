import React, { useState, DragEvent } from 'react';
import { XIcon, UploadCloudIcon, CheckCircleIcon, InfoIcon, FileTextIcon, AlertCircleIcon } from './Icons';

interface CompleteInstallationModalProps {
  isOpen: boolean;
  onClose: () => void;
  orderId: string;
}

const CompleteInstallationModal: React.FC<CompleteInstallationModalProps> = ({ isOpen, onClose, orderId }) => {
  const [isDragOver, setIsDragOver] = useState(false);
  const [file, setFile] = useState<File | null>(null);
  const [notes, setNotes] = useState('');

  if (!isOpen) return null;

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
  };

  const handleDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity" 
        onClick={onClose}
      />

      {/* Modal Content */}
      <div className="relative w-full max-w-2xl transform overflow-hidden rounded-2xl bg-white shadow-2xl transition-all flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-gray-100 px-6 py-5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary-50 text-primary-600">
              <CheckCircleIcon className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-gray-900 leading-tight">Complete Installation</h2>
              <p className="text-sm text-gray-500 mt-0.5">
                Mark order <span className="font-mono font-medium text-gray-700 bg-gray-100 px-1.5 py-0.5 rounded text-xs">{orderId}</span> as completed
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="rounded-full p-2 text-gray-400 hover:bg-gray-100 hover:text-gray-600 transition-colors focus:outline-none focus:ring-2 focus:ring-primary-500"
          >
            <XIcon className="h-5 w-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto px-6 py-6 space-y-8">
          
          {/* Section 1: Document Upload */}
          <div className="space-y-4">
            <div className="flex justify-between items-baseline">
              <div>
                <label className="block text-sm font-semibold text-gray-900">
                  Installation Proof Document
                </label>
                <p className="text-sm text-gray-500 mt-1">
                  Upload photos or signed forms (max 20MB)
                </p>
              </div>
              <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Optional</span>
            </div>

            {/* Info Banner */}
            <div className="flex items-start gap-3 rounded-lg bg-blue-50/50 p-3 text-sm text-blue-700 border border-blue-100">
              <InfoIcon className="h-5 w-5 shrink-0 text-blue-500" />
              <p className="leading-snug">
                You can upload this later if the document isn't immediately available.
              </p>
            </div>

            {/* Upload Area */}
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`
                group relative flex flex-col items-center justify-center rounded-xl border-2 border-dashed p-8 transition-all
                ${isDragOver 
                  ? 'border-primary-500 bg-primary-50' 
                  : 'border-gray-200 bg-gray-50/50 hover:bg-gray-50 hover:border-gray-300'
                }
              `}
            >
              <input 
                type="file" 
                className="absolute inset-0 z-10 h-full w-full cursor-pointer opacity-0"
                onChange={handleFileSelect}
              />
              
              {file ? (
                <div className="flex items-center gap-3 p-2 bg-white rounded-lg border border-gray-200 shadow-sm z-20">
                  <div className="bg-primary-100 p-2 rounded text-primary-600">
                    <FileTextIcon className="h-6 w-6" />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-medium text-gray-900 truncate max-w-[200px]">{file.name}</p>
                    <p className="text-xs text-gray-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                  <button 
                    onClick={(e) => {
                      e.stopPropagation();
                      e.preventDefault();
                      setFile(null);
                    }}
                    className="p-1 hover:bg-gray-100 rounded-full ml-2 text-gray-400 hover:text-red-500"
                  >
                    <XIcon className="h-4 w-4" />
                  </button>
                </div>
              ) : (
                <>
                  <div className={`mb-3 rounded-full bg-white p-3 shadow-sm ring-1 ring-gray-200 transition-transform group-hover:scale-110 ${isDragOver ? 'text-primary-600' : 'text-gray-400'}`}>
                    <UploadCloudIcon className="h-6 w-6" />
                  </div>
                  <p className="text-sm font-medium text-gray-900">
                    <span className="text-primary-600 hover:underline">Click to upload</span> or drag and drop
                  </p>
                  <p className="mt-1 text-xs text-gray-500">PDF, JPG, PNG or Word</p>
                </>
              )}
            </div>
          </div>

          {/* Section 2: Notes */}
          <div className="space-y-3">
            <div className="flex justify-between items-baseline">
              <label htmlFor="notes" className="block text-sm font-semibold text-gray-900">
                Installation Notes
              </label>
              <span className="text-xs font-medium text-gray-400 uppercase tracking-wide">Optional</span>
            </div>
            <div className="relative">
              <textarea
                id="notes"
                rows={4}
                className="block w-full rounded-lg border border-gray-300 bg-white p-3 text-sm text-gray-900 placeholder:text-gray-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 focus:outline-none transition-shadow resize-none"
                placeholder="Add any technical details, equipment used, or important observations..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
              />
              <div className="absolute bottom-2 right-2 text-xs text-gray-300 select-none pointer-events-none">
                //
              </div>
            </div>
          </div>

          {/* Contextual Warning/Next Step */}
          <div className="rounded-lg border border-gray-200 bg-gray-50 p-4">
            <div className="flex gap-3">
              <AlertCircleIcon className="h-5 w-5 text-gray-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-medium text-gray-900">What happens next?</h4>
                <p className="mt-1 text-sm text-gray-600">
                  After completing installation, you can activate the service and start billing once the payment method is verified.
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="border-t border-gray-100 bg-gray-50/80 px-6 py-4 flex flex-col-reverse sm:flex-row sm:justify-end gap-3 backdrop-blur-sm">
          <button
            type="button"
            onClick={onClose}
            className="inline-flex justify-center items-center rounded-lg border border-gray-300 bg-white px-5 py-2.5 text-sm font-medium text-gray-700 shadow-sm hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-gray-200 transition-all"
          >
            Cancel
          </button>
          <button
            type="button"
            className="inline-flex justify-center items-center gap-2 rounded-lg border border-transparent bg-primary-700 px-5 py-2.5 text-sm font-medium text-white shadow-sm hover:bg-primary-800 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 transition-all"
          >
            <CheckCircleIcon className="h-4 w-4" />
            Complete Installation
          </button>
        </div>
      </div>
    </div>
  );
};

export default CompleteInstallationModal;