export const NAV_LINKS = [
  { name: 'Fibre', href: '#', active: false },
  { name: 'LTE', href: '#', active: false },
  { name: '5G', href: '#', active: false },
  { name: 'Gaming', href: '#', active: false },
  { name: 'Business', href: '#', active: false },
  { name: 'Help Centre', href: '#', active: false },
];

export const SIDEBAR_GROUPS = [
  {
    title: "The Legal Stuff",
    items: [
      "Terms and Conditions",
      "Definitions",
      "Use of Website",
      "Code of Conduct",
      "Disclaimer",
      "Privacy Policy",
      "Protection of Minors",
      "PAIA"
    ]
  },
  {
    title: "Product Terms",
    items: [
      "Fibre Internet",
      "Fixed LTE",
      "5G",
      "VoIP",
      "Hosting",
      "Mail",
      "Reseller"
    ]
  },
  {
    title: "Promotions",
    items: [
      "General Promotion Terms",
      "Refer & Earn",
      "Black Friday"
    ]
  }
];

export const FOOTER_LINKS = [
  {
    title: "Our Products",
    links: ["Fibre", "Fixed LTE", "5G", "ADSL", "Business", "Hosting", "Domains", "Security"]
  },
  {
    title: "Useful Links",
    links: ["Switch to Webafrica", "Moving Home", "Refer & Earn", "Network Status", "Speed Test", "Customer Reviews", "Careers", "Legal", "Blog"]
  },
  {
    title: "Customer Zone",
    links: ["Log In", "Pay My Bill", "Top Up Data", "Support"]
  }
];