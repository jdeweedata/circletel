import React from 'react';
import { SIDEBAR_GROUPS } from '../constants';

export const Sidebar: React.FC = () => {
  return (
    <nav className="hidden lg:block w-[280px] flex-shrink-0 pr-8 mt-4">
      <div className="sticky top-28 overflow-y-auto max-h-[calc(100vh-8rem)] pr-4 scrollbar-hide">
        {SIDEBAR_GROUPS.map((group, index) => (
          <div key={index} className="mb-10">
            <h3 className="text-[12px] font-bold text-gray-900 uppercase tracking-[0.15em] mb-4 ml-4">
              {group.title}
            </h3>
            <ul className="space-y-1">
              {group.items.map((item) => (
                <li key={item}>
                  <a
                    href="#"
                    className={`block text-[14px] py-2 transition-all duration-200 ${
                      item === "Terms and Conditions"
                        ? "text-brand-orange font-semibold border-l-[3px] border-brand-orange pl-4 bg-orange-50/50"
                        : "text-gray-500 hover:text-brand-orange border-l-[3px] border-transparent pl-4 hover:border-gray-200"
                    }`}
                  >
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </nav>
  );
};