import React, { useState } from 'react';
import { Menu, X, User, Search, Rss } from 'lucide-react';
import { NAV_LINKS } from '../constants';

export const Navbar: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <header className="fixed w-full top-0 z-50 bg-white border-b border-gray-100 shadow-[0_2px_15px_-3px_rgba(0,0,0,0.07)]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-[88px]">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center cursor-pointer -ml-2 lg:ml-0">
            <div className="flex items-center">
                {/* Logo Icon Simulation */}
                <div className="relative w-10 h-10 flex items-center justify-center mr-2">
                    <div className="absolute inset-0 border-[3px] border-brand-grey rounded-full opacity-20"></div>
                    <div className="absolute inset-0 border-t-[3px] border-l-[3px] border-brand-orange rounded-full rotate-45"></div>
                    <Rss className="text-brand-orange transform -rotate-45" size={20} strokeWidth={3} />
                </div>
                <div className="flex flex-col leading-none">
                    <span className="text-[24px] font-normal tracking-tight text-brand-orange font-[Poppins] lowercase">
                    circle
                    </span>
                    <span className="text-[24px] font-bold tracking-tight text-brand-orange font-[Poppins] uppercase -mt-2">
                    TEL
                    </span>
                </div>
            </div>
          </div>

          {/* Desktop Nav */}
          <div className="hidden xl:flex space-x-8 items-center">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-[15px] font-medium text-gray-600 hover:text-brand-orange transition-colors duration-200"
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Right Side Actions */}
          <div className="hidden md:flex items-center space-x-6">
            <button className="text-gray-500 hover:text-brand-orange">
                <Search size={20} />
            </button>
            <a href="#" className="flex items-center text-[15px] font-semibold text-gray-700 hover:text-brand-orange">
                <User size={18} className="mr-2" />
                Log In
            </a>
            <a href="#" className="bg-brand-orange hover:bg-orange-600 text-white px-6 py-2.5 rounded-full text-[15px] font-semibold transition-colors shadow-md">
                Get Connected
            </a>
          </div>

          {/* Mobile menu button */}
          <div className="xl:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-gray-600 hover:text-brand-orange focus:outline-none p-2"
            >
              {isOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="xl:hidden bg-white border-t border-gray-100 absolute w-full shadow-xl h-screen overflow-y-auto pb-20">
          <div className="px-4 pt-4 pb-6 space-y-1">
            {NAV_LINKS.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block px-3 py-4 text-lg font-medium text-gray-800 border-b border-gray-50 hover:text-brand-orange"
              >
                {link.name}
              </a>
            ))}
            <div className="pt-6 space-y-4">
                 <a href="#" className="block w-full text-center border-2 border-brand-orange text-brand-orange px-6 py-3 rounded-full text-lg font-semibold">
                    Log In
                </a>
                <a href="#" className="block w-full text-center bg-brand-orange text-white px-6 py-3 rounded-full text-lg font-semibold">
                    Get Connected
                </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};