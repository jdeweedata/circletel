import React from 'react';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { LegalContent } from './components/LegalContent';
import { Footer } from './components/Footer';
import { SupportButton } from './components/SupportButton';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-white flex flex-col font-[Poppins]">
      {/* Top Navigation */}
      <Navbar />

      {/* Main Content Area */}
      <main className="flex-grow pt-[88px]"> {/* Padding to account for fixed navbar */}
        <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Left Sidebar (Navigation) */}
            <Sidebar />
            
            {/* Right Content (Legal Text) */}
            <LegalContent />
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
      
      {/* Floating Action Button */}
      <SupportButton />
    </div>
  );
};

export default App;