import React, { useState, useEffect } from 'react';
import { ArrowUp, Edit3, Save, X, RotateCcw, Check } from 'lucide-react';

// Default content structure simulating a database response
const DEFAULT_CONTENT = {
  meta: {
    lastUpdated: "October 2024"
  },
  general: {
    items: [
      "This is an agreement between you and Circle TEL regarding your use of Circle TEL's products, services, computers, interactive information, communications and server management service. All such usage shall be subject to the terms and conditions contained in this agreement and the policies set out below as read with the product-specific terms and conditions applicable to the relevant product or service (collectively, \"the / this Agreement\").",
      "This Agreement applies to all accounts, sub-accounts, and alternative account names associated with your principal account. The Account Holder is responsible for the use of such account, whether under any name or by any person, and for ensuring full compliance with this Agreement by all users of that account.",
      "In circumstances of the Consumer Protection Act, 2008 (\"the CPA\") applying to this Agreement, the provisions of the CPA shall prevail in the event of a conflict between any provision of this Agreement and the provisions of the CPA.",
      "By navigating our website or using our services, you agree to the following policies:"
    ],
    policyLinks: [
      "Acceptable Use Policy", "Privacy Policy", "Code of Conduct", 
      "Dispute Resolution", "Billing Terms", "Take-Down Procedures"
    ]
  },
  acceptableUse: {
    p1: "By using our services, you agree to comply with our Policies and Procedures, including this Acceptable Use Policy (AUP).",
    p2: "You are expected to use the Internet and other networks and services access through the services with respect, courtesy, and responsibility, giving due regard to the rights of other Internet users. We expect you to have a basic knowledge of how the Internet functions, the types of uses which are generally acceptable, and the types of uses which are unacceptable. In other words, common sense dictates what is considered acceptable use.",
    p3: "We reserve the right to sell a maximum of 5 internet services to the same customer, any more than this may be allowed at our discretion but the customer is then automatically classified/deemed a reseller."
  },
  unacceptableUse: {
    p1: "Illegality in any form, including but not limited to activities such as unauthorized distribution or copying of copyrighted material, violation of export restrictions, harassment, fraud, trafficking in obscene material, and other illegal activities.",
    p2: "Circle TEL's services and servers may be used only for lawful purposes. Transmission, distribution, or storage of any material in violation of any applicable law or regulation is prohibited. This includes, without limitation, material protected by copyright, trademark, trade secret, or other intellectual property right used without proper authorization, and material that is obscene, defamatory, constitutes an illegal threat, or violates export control laws.",
    warningTitle: "Prohibited Content:",
    warningText: "Examples of unacceptable content or links: \"Pirated software\", \"Hackers programs\", \"Warez Sites\", \"IRC Bots\", etc.",
    p3: "Due to the nature of a shared web hosting environment, Circle TEL reserves the right to ask customers to upgrade or correct issues pertaining to upgrade their shared web hosting package, or to correct issues on their shared web hosting package should it adversely affect the network or server performance for the majority of our hosting customers."
  },
  security: {
    intro: "Violations of system or network security are prohibited, and may result in criminal and civil liability. Examples include, but are not limited to the following:",
    items: [
      "Unauthorized access, use, probe, or scan of a system's security or authentication measures, data or traffic.",
      "Interference with service to any user, host or network including, without limitation, mail bombing, flooding, deliberate attempts to overload a system and broadcast attacks.",
      "Forging of any TCP-IP packet header or any part of the header information in an email or a newsgroup posting."
    ]
  }
};

export const LegalContent: React.FC = () => {
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [activeSection, setActiveSection] = useState<string>('');
  
  // CMS State
  const [content, setContent] = useState(DEFAULT_CONTENT);
  const [isEditing, setIsEditing] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');

  // Load from local storage on mount
  useEffect(() => {
    const savedContent = localStorage.getItem('cms_content');
    if (savedContent) {
      try {
        setContent(JSON.parse(savedContent));
      } catch (e) {
        console.error("Failed to parse saved content", e);
      }
    }
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      // Scroll to top button visibility
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }

      // Active section tracking
      const sections = ['general', 'acceptable-use', 'unacceptable-use', 'security'];
      const scrollPosition = window.scrollY + 200; // Offset for header and padding

      // Default to nothing or 'general' if at very top
      let current = '';

      for (const section of sections) {
        const element = document.getElementById(section);
        if (element && element.offsetTop < scrollPosition) {
          current = section;
        }
      }
      setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    // Trigger once on mount
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  };

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 120; // Header height + padding
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
      // Optimistically set active section immediately on click
      setActiveSection(id);
    }
  };

  const getLinkClasses = (id: string) => {
    const baseClasses = "flex items-center text-sm transition-all duration-200 group px-3 py-2 rounded-lg";
    if (activeSection === id) {
        return `${baseClasses} text-brand-orange font-bold bg-orange-50 border border-orange-100 shadow-sm`;
    }
    return `${baseClasses} text-gray-600 hover:text-brand-orange hover:bg-gray-50`;
  };

  // --- CMS Handlers ---

  const handleSave = () => {
    localStorage.setItem('cms_content', JSON.stringify(content));
    setIsEditing(false);
    setHasChanges(false);
    setSaveMessage('Changes saved successfully!');
    setTimeout(() => setSaveMessage(''), 3000);
  };

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset all content to default? This cannot be undone.")) {
      setContent(DEFAULT_CONTENT);
      localStorage.removeItem('cms_content');
      setIsEditing(false);
      setHasChanges(false);
    }
  };

  const updateContent = (section: keyof typeof DEFAULT_CONTENT, field: string, value: any, index?: number) => {
    setHasChanges(true);
    setContent(prev => {
      const newSection = { ...prev[section] } as any;
      
      if (index !== undefined && Array.isArray(newSection[field])) {
        const newArray = [...newSection[field]];
        newArray[index] = value;
        newSection[field] = newArray;
      } else {
        newSection[field] = value;
      }

      return {
        ...prev,
        [section]: newSection
      };
    });
  };

  // Helper to render editable text area or display text
  const EditableText = ({ 
    value, 
    onChange, 
    className = "", 
    tag = "p",
    rows = 3
  }: { value: string, onChange: (val: string) => void, className?: string, tag?: any, rows?: number }) => {
    if (isEditing) {
      return (
        <textarea 
          value={value} 
          onChange={(e) => onChange(e.target.value)}
          className={`w-full p-3 border border-gray-300 rounded-lg bg-gray-50 focus:ring-2 focus:ring-brand-orange focus:border-transparent outline-none transition-shadow text-sm ${className}`}
          rows={rows}
        />
      );
    }
    const Tag = tag;
    return <Tag className={className}>{value}</Tag>;
  };

  return (
    <div className="flex-1 min-w-0 bg-white text-[#444] leading-relaxed relative">
      
      {/* CMS Admin Toolbar */}
      <div className="bg-gray-900 text-white p-4 rounded-xl mb-8 flex flex-col sm:flex-row items-center justify-between shadow-lg border border-gray-800">
        <div className="flex items-center mb-4 sm:mb-0">
          <div className="bg-brand-orange p-2 rounded-lg mr-3">
             <Edit3 size={18} className="text-white" />
          </div>
          <div>
            <h3 className="font-bold text-sm">CMS Admin</h3>
            <p className="text-xs text-gray-400">{isEditing ? 'Editing Mode Active' : 'View Mode'}</p>
          </div>
        </div>
        
        <div className="flex items-center gap-3">
          {saveMessage && (
             <span className="text-green-400 text-xs font-medium flex items-center mr-2 animate-fade-in">
                <Check size={14} className="mr-1" /> {saveMessage}
             </span>
          )}
          
          {!isEditing ? (
            <button 
              onClick={() => setIsEditing(true)}
              className="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-xs font-semibold transition-colors"
            >
              <Edit3 size={14} /> Edit Content
            </button>
          ) : (
            <>
              <button 
                onClick={handleReset}
                className="flex items-center gap-2 text-gray-400 hover:text-red-400 px-3 py-2 rounded-lg text-xs font-semibold transition-colors"
                title="Reset to Default"
              >
                <RotateCcw size={14} /> Reset
              </button>
              <button 
                onClick={() => { setIsEditing(false); setContent(JSON.parse(localStorage.getItem('cms_content') || JSON.stringify(DEFAULT_CONTENT))); }}
                className="flex items-center gap-2 bg-transparent border border-gray-600 hover:bg-gray-800 px-4 py-2 rounded-lg text-xs font-semibold transition-colors"
              >
                <X size={14} /> Cancel
              </button>
              <button 
                onClick={handleSave}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${hasChanges ? 'bg-brand-orange hover:bg-orange-600 text-white shadow-md' : 'bg-gray-700 text-gray-400 cursor-not-allowed'}`}
                disabled={!hasChanges}
              >
                <Save size={14} /> Save Changes
              </button>
            </>
          )}
        </div>
      </div>

      {/* Main Title Section */}
      <div className="mb-10 border-b border-gray-100 pb-8">
        <p className="text-brand-orange font-bold text-[11px] uppercase tracking-[0.15em] mb-3">
          It's boring, it's necessary
        </p>
        <h1 className="text-[42px] font-bold text-[#222] tracking-tight leading-tight mb-6">
          Terms & Conditions
        </h1>
        <div className="flex items-center text-gray-500 text-sm italic">
            Last Updated: 
            <EditableText 
              tag="span"
              className="ml-2 font-medium not-italic"
              value={content.meta.lastUpdated} 
              onChange={(val) => updateContent('meta', 'lastUpdated', val)} 
              rows={1}
            />
        </div>
      </div>

      {/* Content Body */}
      <div className="space-y-12 max-w-[850px]">

        {/* Table of Contents */}
        <div className="bg-gray-50 rounded-xl p-6 border border-gray-100 mb-12 sticky top-32 z-10 shadow-sm backdrop-blur-sm bg-gray-50/95">
            <div className="flex items-center justify-between mb-4">
                <h3 className="text-[13px] font-bold text-gray-900 uppercase tracking-widest">
                    Table of Contents
                </h3>
                <span className="text-[10px] text-gray-400 uppercase tracking-wider">
                    {activeSection ? `Current: ${activeSection.replace('-', ' ')}` : 'Select a section'}
                </span>
            </div>
            <nav>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-y-2 gap-x-6">
                    <li>
                        <a 
                            href="#general" 
                            onClick={(e) => scrollToSection(e, 'general')}
                            className={getLinkClasses('general')}
                        >
                            <span className={`font-semibold mr-2 ${activeSection === 'general' ? 'text-brand-orange' : 'text-brand-orange opacity-80'}`}>01.</span> 
                            General
                        </a>
                    </li>
                    <li>
                        <a 
                            href="#acceptable-use" 
                            onClick={(e) => scrollToSection(e, 'acceptable-use')}
                            className={getLinkClasses('acceptable-use')}
                        >
                            <span className={`font-semibold mr-2 ${activeSection === 'acceptable-use' ? 'text-brand-orange' : 'text-brand-orange opacity-80'}`}>02.</span> 
                            Acceptable Use Policy
                        </a>
                    </li>
                    <li>
                        <a 
                            href="#unacceptable-use" 
                            onClick={(e) => scrollToSection(e, 'unacceptable-use')}
                            className={getLinkClasses('unacceptable-use')}
                        >
                            <span className={`font-semibold mr-2 ${activeSection === 'unacceptable-use' ? 'text-brand-orange' : 'text-brand-orange opacity-80'}`}>03.</span> 
                            Unacceptable Use
                        </a>
                    </li>
                    <li>
                        <a 
                            href="#security" 
                            onClick={(e) => scrollToSection(e, 'security')}
                            className={getLinkClasses('security')}
                        >
                            <span className={`font-semibold mr-2 ${activeSection === 'security' ? 'text-brand-orange' : 'text-brand-orange opacity-80'}`}>04.</span> 
                            System & Network Security
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
        
        {/* General */}
        <section className="legal-section scroll-mt-36" id="general">
          <h2 className="text-2xl font-bold text-[#222] mb-6 flex items-center">
            <span className="text-brand-orange mr-3">01.</span> General
          </h2>
          <ol className="list-decimal pl-0 space-y-4 text-[15px] text-gray-600 marker:text-brand-orange marker:font-semibold ml-5">
            {content.general.items.map((item, idx) => (
               <li key={idx} className="pl-2">
                  <EditableText 
                    value={item} 
                    onChange={(val) => updateContent('general', 'items', val, idx)}
                    className={idx === 3 ? "font-medium text-gray-800" : ""}
                  />
               </li>
            ))}
          </ol>
          
          <div className="mt-6 bg-gray-50 p-6 rounded-xl border border-gray-100">
            <ul className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[14px] text-gray-600">
                {content.general.policyLinks.map((policy, idx) => (
                    <li key={idx} className="flex items-center">
                        <div className="w-1.5 h-1.5 bg-brand-orange rounded-full mr-2 flex-shrink-0"></div>
                        <EditableText 
                            value={policy}
                            onChange={(val) => updateContent('general', 'policyLinks', val, idx)}
                            tag="span"
                            rows={1}
                        />
                    </li>
                ))}
            </ul>
          </div>

          <p className="mt-8 font-bold text-[#222] text-sm tracking-wide uppercase border-l-4 border-brand-orange pl-4 py-1">
              Please read these terms and conditions carefully.
          </p>
        </section>

        <hr className="border-gray-100" />

        {/* Acceptable Use Policy */}
        <section className="legal-section scroll-mt-36" id="acceptable-use">
          <h2 className="text-2xl font-bold text-[#222] mb-6 flex items-center">
             <span className="text-brand-orange mr-3">02.</span> Acceptable Use Policy
          </h2>
          <div className="text-[15px] text-gray-600 space-y-4">
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">2.1</strong> 
                <div className="flex-1">
                    <EditableText 
                        value={content.acceptableUse.p1}
                        onChange={(val) => updateContent('acceptableUse', 'p1', val)}
                    />
                </div>
            </div>
            
            <h3 className="text-lg font-bold text-[#222] mt-6 mb-3">General and Acceptable Use</h3>
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">2.2</strong>
                <div className="flex-1">
                     <EditableText 
                        value={content.acceptableUse.p2}
                        onChange={(val) => updateContent('acceptableUse', 'p2', val)}
                        rows={5}
                     />
                </div>
            </div>
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">2.3</strong>
                <div className="flex-1">
                    <EditableText 
                        value={content.acceptableUse.p3}
                        onChange={(val) => updateContent('acceptableUse', 'p3', val)}
                    />
                </div>
            </div>
          </div>
        </section>

        <hr className="border-gray-100" />

        {/* Unacceptable Use */}
        <section className="legal-section scroll-mt-36" id="unacceptable-use">
          <h2 className="text-2xl font-bold text-[#222] mb-6 flex items-center">
            <span className="text-brand-orange mr-3">03.</span> Unacceptable Use
          </h2>
          <div className="text-[15px] text-gray-600 space-y-4">
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">3.1</strong>
                <div className="flex-1">
                    <EditableText 
                        value={content.unacceptableUse.p1}
                        onChange={(val) => updateContent('unacceptableUse', 'p1', val)}
                    />
                </div>
            </div>
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">3.2</strong>
                <div className="flex-1">
                    <EditableText 
                        value={content.unacceptableUse.p2}
                        onChange={(val) => updateContent('unacceptableUse', 'p2', val)}
                        rows={5}
                    />
                </div>
            </div>
            
            <div className="bg-red-50 p-4 rounded-lg border-l-4 border-red-400 text-sm mt-4">
                <span className="font-bold text-red-800 block mb-1">
                     <EditableText 
                        value={content.unacceptableUse.warningTitle}
                        onChange={(val) => updateContent('unacceptableUse', 'warningTitle', val)}
                        tag="span"
                        rows={1}
                     />
                </span>
                <EditableText 
                    value={content.unacceptableUse.warningText}
                    onChange={(val) => updateContent('unacceptableUse', 'warningText', val)}
                    tag="span"
                 />
            </div>
            <div className="flex gap-2">
                <strong className="text-[#222] mt-1">3.3</strong>
                <div className="flex-1">
                    <EditableText 
                        value={content.unacceptableUse.p3}
                        onChange={(val) => updateContent('unacceptableUse', 'p3', val)}
                    />
                </div>
            </div>
          </div>
        </section>

        <hr className="border-gray-100" />

        {/* System and Network Security */}
        <section className="legal-section scroll-mt-36" id="security">
          <h2 className="text-2xl font-bold text-[#222] mb-6 flex items-center">
            <span className="text-brand-orange mr-3">04.</span> System & Network Security
          </h2>
          <div className="mb-4 text-[15px] text-gray-600">
               <EditableText 
                    value={content.security.intro}
                    onChange={(val) => updateContent('security', 'intro', val)}
               />
          </div>
          <ul className="space-y-3 text-[15px] text-gray-600">
             {content.security.items.map((item, idx) => (
                <li key={idx} className="flex items-start">
                    <span className="text-brand-orange font-bold mr-2 mt-0.5">›</span>
                    <div className="flex-1">
                        <EditableText 
                            value={item}
                            onChange={(val) => updateContent('security', 'items', val, idx)}
                        />
                    </div>
                </li>
             ))}
          </ul>
        </section>

        {/* Fade out effect */}
        <div className="py-16 text-center">
            <button className="bg-gray-100 hover:bg-gray-200 text-gray-600 font-semibold py-3 px-8 rounded-full transition-colors text-sm">
                Download Full PDF
            </button>
        </div>
      </div>

      {/* Scroll to Top Button */}
      <button
        onClick={scrollToTop}
        className={`fixed bottom-24 right-6 z-40 bg-gray-800 text-white p-3 rounded-full shadow-lg transition-all duration-300 transform hover:bg-brand-orange hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-orange ${
          showScrollTop ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10 pointer-events-none'
        }`}
        aria-label="Scroll to top"
      >
        <ArrowUp size={20} />
      </button>
    </div>
  );
};
