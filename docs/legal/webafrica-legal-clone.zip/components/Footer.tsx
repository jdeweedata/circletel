import React from 'react';
import { FOOTER_LINKS } from '../constants';
import { Facebook, Twitter, Youtube, Instagram, Linkedin, Rss } from 'lucide-react';

export const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0f1f38] text-white pt-16 pb-8 font-[Poppins]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Section: App Prompt */}
        <div className="border-b border-gray-700/50 pb-12 mb-12">
            <div className="bg-gradient-to-r from-brand-orange to-brand-orange/80 rounded-2xl p-8 md:p-10 flex flex-col md:flex-row items-center justify-between shadow-2xl relative overflow-hidden">
                {/* Decorative circle */}
                <div className="absolute -right-20 -top-20 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
                
                <div className="z-10 text-center md:text-left mb-6 md:mb-0">
                    <h3 className="text-2xl font-bold mb-2">Get the Circle TEL App</h3>
                    <p className="text-white/90">Your one-stop solution to manage your account, billing and services.</p>
                </div>
                <div className="flex flex-wrap justify-center gap-3 z-10">
                    <button className="bg-black/30 hover:bg-black/50 transition-colors rounded-lg p-2 border border-white/20 backdrop-blur-sm">
                        <div className="text-[10px] uppercase leading-none">Download on the</div>
                        <div className="text-sm font-bold">App Store</div>
                    </button>
                    <button className="bg-black/30 hover:bg-black/50 transition-colors rounded-lg p-2 border border-white/20 backdrop-blur-sm">
                        <div className="text-[10px] uppercase leading-none">Get it on</div>
                        <div className="text-sm font-bold">Google Play</div>
                    </button>
                    <button className="bg-black/30 hover:bg-black/50 transition-colors rounded-lg p-2 border border-white/20 backdrop-blur-sm">
                        <div className="text-[10px] uppercase leading-none">Explore it on</div>
                        <div className="text-sm font-bold">AppGallery</div>
                    </button>
                </div>
            </div>
        </div>

        {/* Middle Section: Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-16">
          
          {/* Contact Column */}
          <div className="col-span-1 space-y-6">
             <div className="flex items-center -ml-1">
                {/* Footer Logo */}
                <div className="relative w-8 h-8 flex items-center justify-center mr-2">
                    <div className="absolute inset-0 border-[2px] border-gray-400 rounded-full opacity-30"></div>
                    <div className="absolute inset-0 border-t-[2px] border-l-[2px] border-brand-orange rounded-full rotate-45"></div>
                    <Rss className="text-brand-orange transform -rotate-45" size={16} />
                </div>
                <div className="flex flex-col leading-none">
                    <span className="text-[20px] font-normal tracking-tight text-white lowercase">
                    circle
                    </span>
                    <span className="text-[20px] font-bold tracking-tight text-brand-orange uppercase -mt-1.5">
                    TEL
                    </span>
                </div>
             </div>
             <div className="text-gray-400 text-sm space-y-2 leading-relaxed">
                <p>We make internet easy. Whether it's for your home or business, we've got you covered.</p>
             </div>
             <div className="pt-2">
                 <p className="text-brand-orange font-bold text-sm mb-1">Sales & Support</p>
                 <p className="text-2xl font-bold text-white">021 464 9500</p>
                 <p className="text-gray-500 text-xs mt-1">Available Mon-Sun, 8am - 8pm</p>
             </div>
          </div>

          {/* Links Columns */}
          {FOOTER_LINKS.map((column, idx) => (
            <div key={idx} className="col-span-1">
              <h4 className="text-[13px] font-bold uppercase tracking-widest text-white mb-6 border-b border-brand-orange inline-block pb-1">
                {column.title}
              </h4>
              <ul className="space-y-3">
                {column.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-[14px] text-gray-400 hover:text-brand-orange transition-colors flex items-center group">
                      <span className="w-0 group-hover:w-2 transition-all duration-300 overflow-hidden bg-brand-orange h-[2px] mr-0 group-hover:mr-2"></span>
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

         <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
             <div className="text-xs text-gray-500 mb-4 md:mb-0 flex flex-col md:flex-row items-center">
                 <span className="mr-4">Copyright © 2025 Circle TEL.</span>
                 <div className="flex space-x-4 mt-2 md:mt-0">
                    <a href="#" className="hover:text-white">Privacy Policy</a>
                    <a href="#" className="hover:text-white">Terms of Use</a>
                 </div>
             </div>
             
             <div className="flex space-x-5">
                <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-orange hover:text-white transition-all"><Facebook size={16} /></a>
                <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-orange hover:text-white transition-all"><Twitter size={16} /></a>
                <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-orange hover:text-white transition-all"><Instagram size={16} /></a>
                <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-orange hover:text-white transition-all"><Youtube size={16} /></a>
                <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center text-gray-400 hover:bg-brand-orange hover:text-white transition-all"><Linkedin size={16} /></a>
             </div>
         </div>
      </div>
    </footer>
  );
};